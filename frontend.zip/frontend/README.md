# NotesApp - Next.js + Flask + MongoDB

A modern note-taking application built with Next.js frontend, Flask backend, and MongoDB database.

## 🚀 Features

- **User Authentication**: Secure signup/login with JWT tokens
- **Note Management**: Create, read, update, and delete notes
- **Real-time Updates**: Instant UI updates with Zustand state management
- **Responsive Design**: Beautiful UI built with Tailwind CSS
- **Modern Stack**: Next.js 14, Flask 3, MongoDB 7

## 🏗️ Architecture

- **Frontend**: Next.js 14 with TypeScript and Tailwind CSS
- **Backend**: Flask 3 with JWT authentication
- **Database**: MongoDB with optimized indexes
- **State Management**: Zustand for client-side state
- **Styling**: Tailwind CSS with custom components

## 📁 Project Structure

```
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── dashboard/         # Dashboard page
│   │   ├── signin/           # Sign in page
│   │   ├── signup/           # Sign up page
│   │   ├── globals.css       # Global styles
│   │   ├── layout.tsx        # Root layout
│   │   └── page.tsx          # Home page
│   ├── components/            # React components
│   │   ├── layout/           # Layout components
│   │   └── notes/            # Note-related components
│   ├── store/                # Zustand stores
│   ├── services/             # API services
│   └── types/                # TypeScript types
├── backend/                   # Flask backend
│   ├── app.py               # Main Flask application
│   ├── database/            # Database connection
│   ├── models/              # Data models
│   └── requirements.txt     # Python dependencies
├── docker-compose.yml        # Docker services
└── package.json             # Frontend dependencies
```

## 🛠️ Prerequisites

- **Node.js** 18+ and **npm** or **yarn**
- **Python** 3.11+
- **MongoDB** 7.0+ (or Docker)
- **Docker** and **Docker Compose** (optional)

## 🚀 Quick Start

### Option 1: Using Docker (Recommended)

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd notes-app
   ```

2. **Start the services**
   ```bash
   docker-compose up -d
   ```

3. **Install frontend dependencies**
   ```bash
   npm install
   ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

### Option 2: Manual Setup

1. **Start MongoDB**
   ```bash
   # Install MongoDB locally or use MongoDB Atlas
   mongod
   ```

2. **Setup Flask Backend**
   ```bash
   cd backend
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
   ```

3. **Setup Next.js Frontend**
   ```bash
   npm install
   npm run dev
   ```

## 🔧 Configuration

### Environment Variables

Create `.env.local` in the root directory:

```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api/v1
```

Create `.env` in the backend directory:

```env
MONGO_URI=mongodb://localhost:27017/
DATABASE_NAME=notes_app
JWT_SECRET_KEY=your-super-secret-jwt-key-change-in-production
FLASK_ENV=development
FLASK_DEBUG=True
```

### MongoDB Connection

The application connects to MongoDB using the following default settings:
- **Host**: localhost
- **Port**: 27017
- **Database**: notes_app
- **Collections**: users, notes

## 📱 API Endpoints

### Authentication
- `POST /api/v1/auth/register` - User registration
- `POST /api/v1/auth/login` - User login
- `GET /api/v1/auth/me` - Get current user

### Notes
- `GET /api/v1/notes` - Get user notes (with pagination)
- `POST /api/v1/notes` - Create new note
- `GET /api/v1/notes/{id}` - Get specific note
- `PUT /api/v1/notes/{id}` - Update note
- `DELETE /api/v1/notes/{id}` - Delete note

## 🎨 Customization

### Styling
- Modify `src/app/globals.css` for global styles
- Update `tailwind.config.js` for theme customization
- Use Tailwind CSS classes for component styling

### Components
- All components are in `src/components/`
- Follow the existing pattern for new components
- Use TypeScript interfaces for props

### Backend
- Add new routes in `backend/app.py`
- Create new models in `backend/models/`
- Extend database functionality in `backend/database/`

## 🧪 Development

### Frontend Development
```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run lint         # Run ESLint
```

### Backend Development
```bash
cd backend
python app.py        # Start Flask development server
```

### Database Management
```bash
# Connect to MongoDB shell
mongosh

# Switch to database
use notes_app

# View collections
show collections

# View documents
db.users.find()
db.notes.find()
```

## 🐳 Docker Commands

```bash
# Start services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down

# Rebuild and restart
docker-compose up -d --build

# Remove volumes (WARNING: This will delete all data)
docker-compose down -v
```

## 🔒 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: Bcrypt for secure password storage
- **CORS Protection**: Configured for frontend-backend communication
- **Input Validation**: Server-side validation for all inputs
- **User Isolation**: Users can only access their own notes

## 📊 Performance Optimizations

- **MongoDB Indexes**: Optimized queries with proper indexing
- **Pagination**: Efficient note loading with pagination
- **State Management**: Optimized re-renders with Zustand
- **Image Optimization**: Next.js built-in image optimization
- **Code Splitting**: Automatic code splitting with Next.js

## 🚀 Deployment

### Frontend (Vercel/Netlify)
1. Connect your repository
2. Set environment variables
3. Deploy automatically on push

### Backend (Heroku/DigitalOcean)
1. Set environment variables
2. Install dependencies from `requirements.txt`
3. Run `python app.py`

### Database (MongoDB Atlas)
1. Create MongoDB Atlas cluster
2. Update `MONGO_URI` in environment variables
3. Configure network access

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License.

## 🆘 Support

If you encounter any issues:

1. Check the logs for error messages
2. Verify environment variables are set correctly
3. Ensure MongoDB is running and accessible
4. Check that all dependencies are installed

## 🔄 Migration from Previous Version

This project has been converted from:
- **Frontend**: Vite + React → Next.js 14
- **Backend**: FastAPI → Flask
- **Database**: SQLite → MongoDB

Key changes:
- Updated routing to use Next.js App Router
- Converted FastAPI endpoints to Flask routes
- Replaced SQLAlchemy with PyMongo
- Updated state management patterns
- Modernized component structure

---

**Happy Note-Taking! 📝✨**
#   N o t e s - a p p l i c a t i o n  
 #   N o t e s - a p p l i c a t i o n  
 