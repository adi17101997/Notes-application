#!/bin/bash

echo "🚀 Starting NotesApp - Next.js + Flask + MongoDB"

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker is not running. Please start Docker first."
    exit 1
fi

echo "📦 Starting MongoDB and Flask backend..."
docker-compose up -d

echo "⏳ Waiting for services to be ready..."
sleep 10

echo "🔧 Installing frontend dependencies..."
npm install

echo "🌐 Starting Next.js development server..."
npm run dev

echo "✅ NotesApp is starting up!"
echo "📱 Frontend: http://localhost:3000"
echo "🔧 Backend: http://localhost:5000"
echo "🗄️  MongoDB: localhost:27017"
echo ""
echo "Press Ctrl+C to stop all services"
