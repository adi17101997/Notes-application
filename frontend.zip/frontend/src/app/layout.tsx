import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'NotesApp - Your Personal Note Taking Solution',
  description: 'A beautiful and intuitive note-taking application to organize your thoughts and ideas efficiently.',
  keywords: 'notes, note-taking, productivity, organization, thoughts, ideas, writing',
  openGraph: {
    title: 'NotesApp - Your Personal Note Taking Solution',
    description: 'A beautiful and intuitive note-taking application to organize your thoughts and ideas efficiently.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'NotesApp - Your Personal Note Taking Solution',
    description: 'A beautiful and intuitive note-taking application to organize your thoughts and ideas efficiently.',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-screen bg-gray-50">
          {children}
        </div>
      </body>
    </html>
  )
}
