'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/authStore';
import { useNotesStore } from '@/store/notesStore';
import Header from '@/components/layout/Header';
import NoteCard from '@/components/notes/NoteCard';
import NoteForm from '@/components/notes/NoteForm';
import EmptyState from '@/components/notes/EmptyState';

export default function DashboardPage() {
  const { isAuthenticated, user } = useAuthStore();
  const { notes, loading, loadNotes } = useNotesStore();
  const [showNoteForm, setShowNoteForm] = useState(false);
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/signin');
      return;
    }
    loadNotes();
  }, [isAuthenticated, router, loadNotes]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Welcome back, {user?.user_name}!
            </h1>
            <p className="text-gray-600 mt-2">
              Manage your notes and stay organized
            </p>
          </div>
          
          <button
            onClick={() => setShowNoteForm(true)}
            className="btn-primary"
          >
            Add New Note
          </button>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
          </div>
        ) : notes.length === 0 ? (
          <EmptyState onAddNote={() => setShowNoteForm(true)} />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {notes.map((note) => (
              <NoteCard key={note.note_id} note={note} />
            ))}
          </div>
        )}
      </main>

      {showNoteForm && (
        <NoteForm
          onClose={() => setShowNoteForm(false)}
          onSubmit={() => {
            setShowNoteForm(false);
            loadNotes();
          }}
        />
      )}
    </div>
  );
}
