// User types matching backend API
export interface User {
  user_id: string;
  user_name: string;
  user_email: string;
  created_on: string;
  last_update: string;
}

// Note types matching backend API
export interface Note {
  note_id: string;
  note_title: string;
  note_content: string;
  created_on: string;
  last_update: string;
  user_id: string;
}

// API response types
export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: User;
}

export interface NotesListResponse {
  notes: Note[];
  total: number;
  page: number;
  per_page: number;
}

// Frontend state types
export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userName: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  clearError: () => void;
}

export interface NotesState {
  notes: Note[];
  loading: boolean;
  error: string | null;
  total: number;
  page: number;
  per_page: number;
  addNote: (note: Omit<Note, 'note_id' | 'created_on' | 'last_update' | 'user_id'>) => Promise<void>;
  updateNote: (id: string, updates: Partial<Note>) => Promise<void>;
  deleteNote: (id: string) => Promise<void>;
  loadNotes: (page?: number, per_page?: number, search?: string) => Promise<void>;
  clearError: () => void;
}

// Form types
export interface NoteFormData {
  note_title: string;
  note_content: string;
}

export interface UserFormData {
  user_name: string;
  user_email: string;
  password: string;
}