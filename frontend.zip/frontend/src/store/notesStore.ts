import { create } from 'zustand';
import { notesAPI } from '@/services/api';
import { Note } from '@/types';

interface NotesState {
  notes: Note[];
  loading: boolean;
  error: string | null;
  total: number;
  page: number;
  per_page: number;
  addNote: (note: Omit<Note, 'note_id' | 'created_on' | 'last_update' | 'user_id'>) => Promise<void>;
  updateNote: (id: string, updates: Partial<Note>) => Promise<void>;
  deleteNote: (id: string) => Promise<void>;
  loadNotes: (page?: number, per_page?: number, search?: string) => Promise<void>;
  clearError: () => void;
}

export const useNotesStore = create<NotesState>((set, get) => ({
  notes: [],
  loading: false,
  error: null,
  total: 0,
  page: 1,
  per_page: 20,

  addNote: async (noteData) => {
    set({ loading: true, error: null });
    
    try {
      const newNote = await notesAPI.createNote(noteData);
      set((state) => ({
        notes: [newNote, ...state.notes],
        loading: false,
        total: state.total + 1,
      }));
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || 'Failed to create note';
      set({
        loading: false,
        error: errorMessage,
      });
      throw error;
    }
  },

  updateNote: async (noteId, updates) => {
    set({ loading: true, error: null });
    
    try {
      const updatedNote = await notesAPI.updateNote(noteId, updates);
      set((state) => ({
        notes: state.notes.map((note) =>
          note.note_id === noteId ? { ...note, ...updatedNote } : note
        ),
        loading: false,
      }));
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || 'Failed to update note';
      set({
        loading: false,
        error: errorMessage,
      });
      throw error;
    }
  },

  deleteNote: async (noteId) => {
    set({ loading: true, error: null });
    
    try {
      await notesAPI.deleteNote(noteId);
      set((state) => ({
        notes: state.notes.filter((note) => note.note_id !== noteId),
        loading: false,
        total: state.total - 1,
      }));
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || 'Failed to delete note';
      set({
        loading: false,
        error: errorMessage,
      });
      throw error;
    }
  },

  loadNotes: async (page = 1, per_page = 20, search = '') => {
    set({ loading: true, error: null });
    
    try {
      const response = await notesAPI.getNotes({ page, per_page, search });
      set({
        notes: response.notes,
        total: response.total,
        page: response.page,
        per_page: response.per_page,
        loading: false,
        error: null,
      });
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || 'Failed to load notes';
      set({
        loading: false,
        error: errorMessage,
      });
    }
  },

  clearError: () => {
    set({ error: null });
  },
}));