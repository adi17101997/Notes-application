import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authAPI } from '@/services/api';
import { User, AuthResponse } from '@/types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userName: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  clearError: () => void;
  checkAuth: () => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      loading: false,
      error: null,

      login: async (email: string, password: string) => {
        set({ loading: true, error: null });
        
        try {
          const response: AuthResponse = await authAPI.login({ user_email: email, password });
          
          // Store token in localStorage
          localStorage.setItem('auth-token', response.access_token);
          
          set({
            user: response.user,
            isAuthenticated: true,
            loading: false,
            error: null,
          });
          
          return true;
        } catch (error: any) {
          const errorMessage = error.response?.data?.message || 'Login failed';
          set({
            loading: false,
            error: errorMessage,
          });
          return false;
        }
      },

      register: async (userName: string, email: string, password: string) => {
        set({ loading: true, error: null });
        
        try {
          const response: AuthResponse = await authAPI.register({
            user_name: userName,
            user_email: email,
            password,
          });
          
          // Store token in localStorage
          localStorage.setItem('auth-token', response.access_token);
          
          set({
            user: response.user,
            isAuthenticated: true,
            loading: false,
            error: null,
          });
          
          return true;
        } catch (error: any) {
          const errorMessage = error.response?.data?.message || 'Registration failed';
          set({
            loading: false,
            error: errorMessage,
          });
          return false;
        }
      },

      logout: () => {
        localStorage.removeItem('auth-token');
        set({
          user: null,
          isAuthenticated: false,
          error: null,
        });
      },

      clearError: () => {
        set({ error: null });
      },

      checkAuth: async () => {
        const token = localStorage.getItem('auth-token');
        if (!token) {
          set({ isAuthenticated: false, user: null });
          return;
        }

        try {
          const user = await authAPI.getCurrentUser();
          set({
            user,
            isAuthenticated: true,
            error: null,
          });
        } catch (error) {
          localStorage.removeItem('auth-token');
          set({
            user: null,
            isAuthenticated: false,
            error: null,
          });
        }
      },
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);