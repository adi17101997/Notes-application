'use client';

import { useState } from 'react';
import { Note } from '@/types';
import { useNotesStore } from '@/store/notesStore';

interface NoteCardProps {
  note: Note;
}

export default function NoteCard({ note }: NoteCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState(note.note_title);
  const [content, setContent] = useState(note.note_content);
  const { updateNote, deleteNote } = useNotesStore();

  const handleSave = async () => {
    try {
      await updateNote(note.note_id, { note_title: title, note_content: content });
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to update note:', error);
    }
  };

  const handleDelete = async () => {
    if (confirm('Are you sure you want to delete this note?')) {
      try {
        await deleteNote(note.note_id);
      } catch (error) {
        console.error('Failed to delete note:', error);
      }
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  if (isEditing) {
    return (
      <div className="card">
        <div className="space-y-4">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="input-field font-semibold text-lg"
            placeholder="Note title"
          />
          
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="input-field min-h-[120px] resize-none"
            placeholder="Note content"
          />
          
          <div className="flex space-x-2">
            <button
              onClick={handleSave}
              className="btn-primary flex-1"
            >
              Save
            </button>
            <button
              onClick={() => setIsEditing(false)}
              className="btn-secondary flex-1"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="card hover:shadow-lg transition-shadow duration-200">
      <div className="space-y-3">
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-semibold text-gray-900 line-clamp-2">
            {note.note_title}
          </h3>
          
          <div className="flex space-x-2">
            <button
              onClick={() => setIsEditing(true)}
              className="text-primary-600 hover:text-primary-700 text-sm font-medium"
            >
              Edit
            </button>
            <button
              onClick={handleDelete}
              className="text-red-600 hover:text-red-700 text-sm font-medium"
            >
              Delete
            </button>
          </div>
        </div>
        
        <p className="text-gray-600 line-clamp-4">
          {note.note_content}
        </p>
        
        <div className="text-xs text-gray-500">
          Last updated: {formatDate(note.last_update)}
        </div>
      </div>
    </div>
  );
}