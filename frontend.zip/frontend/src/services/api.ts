import axios, { AxiosInstance, AxiosResponse } from 'axios';

// API base configuration
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api/v1';

// Create axios instance with default config
const api: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('auth-token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response: AxiosResponse) => response,
  (error) => {
    if (error.response?.status === 401 && typeof window !== 'undefined') {
      // Token expired or invalid, redirect to login
      localStorage.removeItem('auth-token');
      window.location.href = '/signin';
    }
    return Promise.reject(error);
  }
);

// API response types
export interface ApiResponse<T> {
  data: T;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  per_page: number;
}

// Auth API
export const authAPI = {
  register: async (userData: {
    user_name: string;
    user_email: string;
    password: string;
  }) => {
    const response = await api.post('/auth/register', userData);
    return response.data;
  },

  login: async (credentials: {
    user_email: string;
    password: string;
  }) => {
    const response = await api.post('/auth/login', credentials);
    return response.data;
  },

  getCurrentUser: async () => {
    const response = await api.get('/auth/me');
    return response.data;
  },
};

// Notes API
export const notesAPI = {
  getNotes: async (params?: {
    page?: number;
    per_page?: number;
    search?: string;
    sort_by?: string;
    sort_order?: 'asc' | 'desc';
  }) => {
    const response = await api.get('/notes', { params });
    return response.data;
  },

  getNote: async (noteId: string) => {
    const response = await api.get(`/notes/${noteId}`);
    return response.data;
  },

  createNote: async (noteData: {
    note_title: string;
    note_content: string;
  }) => {
    const response = await api.post('/notes', noteData);
    return response.data;
  },

  updateNote: async (
    noteId: string,
    noteData: {
      note_title?: string;
      note_content?: string;
    }
  ) => {
    const response = await api.put(`/notes/${noteId}`, noteData);
    return response.data;
  },

  deleteNote: async (noteId: string) => {
    await api.delete(`/notes/${noteId}`);
  },

  getNotesCount: async () => {
    const response = await api.get('/notes/stats/count');
    return response.data;
  },
};

export default api;
