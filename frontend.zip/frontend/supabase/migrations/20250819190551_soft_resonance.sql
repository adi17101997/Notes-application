-- Initialize database for NotesApp
CREATE DATABASE IF NOT EXISTS notesapp;
USE notesapp;

-- Grant privileges to the application user
GRANT ALL PRIVILEGES ON notesapp.* TO 'notesapp_user'@'%';
FLUSH PRIVILEGES;