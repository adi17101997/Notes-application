from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class NoteBase(BaseModel):
    note_title: str
    note_content: str

class NoteCreate(NoteBase):
    pass

class NoteUpdate(BaseModel):
    note_title: Optional[str] = None
    note_content: Optional[str] = None

class NoteResponse(NoteBase):
    note_id: str
    user_id: str
    created_on: datetime
    last_update: datetime
    
    class Config:
        from_attributes = True

class NoteListResponse(BaseModel):
    notes: list[NoteResponse]
    total: int
    page: int
    per_page: int