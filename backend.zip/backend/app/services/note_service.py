from sqlalchemy.orm import Session
from sqlalchemy import desc, asc
from fastapi import HTTPException, status
from ..models.note import Note
from ..schemas.note import NoteCreate, NoteUpdate
from typing import Optional, List, Tuple

class NoteService:
    @staticmethod
    def create_note(db: Session, note_data: NoteCreate, user_id: str) -> Note:
        """Create a new note for a user."""
        db_note = Note(
            note_title=note_data.note_title,
            note_content=note_data.note_content,
            user_id=user_id
        )
        db.add(db_note)
        db.commit()
        db.refresh(db_note)
        return db_note
    
    @staticmethod
    def get_user_notes(
        db: Session, 
        user_id: str, 
        page: int = 1, 
        per_page: int = 10,
        search: Optional[str] = None,
        sort_by: str = "created_on",
        sort_order: str = "desc"
    ) -> Tuple[List[Note], int]:
        """Get paginated notes for a user with optional search and sorting."""
        query = db.query(Note).filter(Note.user_id == user_id)
        
        # Apply search filter
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                (Note.note_title.like(search_term)) | 
                (Note.note_content.like(search_term))
            )
        
        # Apply sorting
        sort_column = getattr(Note, sort_by, Note.created_on)
        if sort_order.lower() == "desc":
            query = query.order_by(desc(sort_column))
        else:
            query = query.order_by(asc(sort_column))
        
        # Get total count
        total = query.count()
        
        # Apply pagination
        offset = (page - 1) * per_page
        notes = query.offset(offset).limit(per_page).all()
        
        return notes, total
    
    @staticmethod
    def get_note_by_id(db: Session, note_id: str, user_id: str) -> Optional[Note]:
        """Get a specific note by ID for a user."""
        return db.query(Note).filter(
            Note.note_id == note_id,
            Note.user_id == user_id
        ).first()
    
    @staticmethod
    def update_note(db: Session, note_id: str, user_id: str, note_data: NoteUpdate) -> Optional[Note]:
        """Update a note."""
        note = NoteService.get_note_by_id(db, note_id, user_id)
        if not note:
            return None
        
        update_data = note_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(note, field, value)
        
        db.commit()
        db.refresh(note)
        return note
    
    @staticmethod
    def delete_note(db: Session, note_id: str, user_id: str) -> bool:
        """Delete a note."""
        note = NoteService.get_note_by_id(db, note_id, user_id)
        if not note:
            return False
        
        db.delete(note)
        db.commit()
        return True
    
    @staticmethod
    def get_user_notes_count(db: Session, user_id: str) -> int:
        """Get total count of notes for a user."""
        return db.query(Note).filter(Note.user_id == user_id).count()