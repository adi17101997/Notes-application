from datetime import datetime
from typing import Optional

class User:
    def __init__(
        self,
        user_id: str,
        user_name: str,
        user_email: str,
        password: str,
        created_on: Optional[datetime] = None,
        last_update: Optional[datetime] = None
    ):
        self.user_id = user_id
        self.user_name = user_name
        self.user_email = user_email
        self.password = password
        self.created_on = created_on or datetime.utcnow()
        self.last_update = last_update or datetime.utcnow()
    
    def to_dict(self):
        """Convert user to dictionary"""
        return {
            'user_id': self.user_id,
            'user_name': self.user_name,
            'user_email': self.user_email,
            'password': self.password,
            'created_on': self.created_on,
            'last_update': self.last_update
        }
    
    @classmethod
    def from_dict(cls, data: dict):
        """Create user from dictionary"""
        return cls(
            user_id=data['user_id'],
            user_name=data['user_name'],
            user_email=data['user_email'],
            password=data['password'],
            created_on=data.get('created_on'),
            last_update=data.get('last_update')
        )
    
    def update(self, **kwargs):
        """Update user fields"""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        self.last_update = datetime.utcnow()
    
    def __repr__(self):
        return f"User(user_id='{self.user_id}', user_name='{self.user_name}', user_email='{self.user_email}')"
