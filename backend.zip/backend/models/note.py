from datetime import datetime
from typing import Optional

class Note:
    def __init__(
        self,
        note_id: str,
        note_title: str,
        note_content: str,
        user_id: str,
        created_on: Optional[datetime] = None,
        last_update: Optional[datetime] = None
    ):
        self.note_id = note_id
        self.note_title = note_title
        self.note_content = note_content
        self.user_id = user_id
        self.created_on = created_on or datetime.utcnow()
        self.last_update = last_update or datetime.utcnow()
    
    def to_dict(self):
        """Convert note to dictionary"""
        return {
            'note_id': self.note_id,
            'note_title': self.note_title,
            'note_content': self.note_content,
            'user_id': self.user_id,
            'created_on': self.created_on,
            'last_update': self.last_update
        }
    
    @classmethod
    def from_dict(cls, data: dict):
        """Create note from dictionary"""
        return cls(
            note_id=data['note_id'],
            note_title=data['note_title'],
            note_content=data['note_content'],
            user_id=data['user_id'],
            created_on=data.get('created_on'),
            last_update=data.get('last_update')
        )
    
    def update(self, **kwargs):
        """Update note fields"""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        self.last_update = datetime.utcnow()
    
    def __repr__(self):
        return f"Note(note_id='{self.note_id}', note_title='{self.note_title}', user_id='{self.user_id}')"
